let students = JSON.parse(localStorage.getItem("students")) || [];

function saveToLocalStorage() {
  localStorage.setItem("students", JSON.stringify(students));
}

function renderTable() {
  const table = document.getElementById("studentTable");
  table.innerHTML = "";

  students.forEach((student, index) => {
    table.innerHTML += `
      <tr>
        <td>${student.name}</td>
        <td>${student.age}</td>
        <td>${student.course}</td>
        <td>
          <button class="update-btn" onclick="editStudent(${index})">Edit</button>
          <button class="delete-btn" onclick="deleteStudent(${index})">Delete</button>
        </td>
      </tr>
    `;
  });
}

function addStudent() {
  const name = document.getElementById("name").value;
  const age = document.getElementById("age").value;
  const course = document.getElementById("course").value;

  if (!name || !age || !course) {
    alert("Please fill all fields");
    return;
  }

  students.push({ name, age, course });
  saveToLocalStorage();
  renderTable();
  clearFields();
}

function editStudent(index) {
  const student = students[index];
  document.getElementById("studentId").value = index;
  document.getElementById("name").value = student.name;
  document.getElementById("age").value = student.age;
  document.getElementById("course").value = student.course;
}

function updateStudent() {
  const index = document.getElementById("studentId").value;

  if (index === "") {
    alert("Select a student to update");
    return;
  }

  students[index] = {
    name: document.getElementById("name").value,
    age: document.getElementById("age").value,
    course: document.getElementById("course").value
  };

  saveToLocalStorage();
  renderTable();
  clearFields();
}

function deleteStudent(index) {
  if (confirm("Are you sure you want to delete?")) {
    students.splice(index, 1);
    saveToLocalStorage();
    renderTable();
  }
}

function clearFields() {
  document.getElementById("studentId").value = "";
  document.getElementById("name").value = "";
  document.getElementById("age").value = "";
  document.getElementById("course").value = "";
}

// Load data on page load
renderTable();